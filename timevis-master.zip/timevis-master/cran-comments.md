# Version 0.1

### Test environments

* Windows 7, R 3.3.0 (local)
* ubuntu 12.04, R 3.3.1 (on travis-ci)
* ubuntu 14.04, R 3.2.1 (on my DigitalOcean droplet)

## Round 1

### Submission comments

2016-07-25

One NOTE about the invalid CRAN URL of the package (the URL will be valid after being accepted to CRAN)

### Reviewer comments

2016-07-25 Duncan Murdoch

Your DESCRIPTION file should give credit to all authors.  In particular, the vis-timeline.min.js file contains uncredited source.

Please fix and resubmit.

## Round 2

### Submission comments

2016-07-25

Added author info to DESCRIPTION

### Reviewer comments

2016-07-25 Duncan Murdoch

Thanks, on CRAN now


# Version 0.2

### Test environments

* Windows 7, R 3.3.1 (local)
* ubuntu 12.04, R 3.3.1 (on travis-ci)
* ubuntu 14.04, R 3.2.1 (on my DigitalOcean droplet)

## Round 1

### Submission comments

2016-08-24

No errors, warnings or notes

### Reviewer comments

2016-08-24 Kurt Hornik

Thanks, on CRAN now

# Version 0.3

### Test environments

* Windows 7, R 3.3.1 (local)
* ubuntu 12.04, R 3.3.1 (on travis-ci)
* ubuntu 14.04, R 3.2.1 (on my DigitalOcean droplet)

## Round 1

### Submission comments

2016-08-29

added VignetteBuilder field to DESCRIPTION file as per CRAN's request

### Reviewer comments

2016-08-29 Duncan Murdoch

Thanks, on CRAN now.

# Version 0.4

### Test environments

* Windows 7, R 3.3.1 (local)
* ubuntu 12.04, R 3.3.1 (on travis-ci)
* ubuntu 14.04, R 3.2.1 (on my DigitalOcean droplet)

## Round 1

### Submission comments

2016-09-16

no errors, warnings, or notes

### Reviewer comments

2016-09-16 Uwe Ligges

Thanks, on CRAN now.

Next time (and now in your master sources), please single quote RStudio and other software names in your Description.
